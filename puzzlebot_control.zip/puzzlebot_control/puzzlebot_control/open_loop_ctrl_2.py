import rclpy
from rclpy.node import Node
import numpy as np
from geometry_msgs.msg import Twist
from puzzlebot_msgs.msg import CustomPose

class OpenLoopCtrl(Node):
    def __init__(self):
        super().__init__('open_loop_ctrl')

        self.wait_for_ros_time()

        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.pose_sub = self.create_subscription(CustomPose, 'pose', self.pose_callback, 10)

        # Estado 3: Esperando meta, 0: Girando, 1: Avanzando, 2: Parada
        self.state = 3  
        self.state_start_time = self.get_clock().now()

        # ==========================================================
        # KPs RE-CALIBRADOS PARA VELOCIDAD BAJA (0.15 m/s)
        # ==========================================================
        self.kp_lineal = 0.88   # Bajamos de 0.93 para que frene un poco antes en la distancia
        self.kp_giro = 0.84     # Bajamos de 0.9375 para corregir que giraba 100 grados en vez de 90
        
        self.w_max = 0.5 

        self.rotate_time = 0.0
        self.forward_time = 0.0
        self.v_actual = 0.0
        self.dir_giro = 1.0

        self.timer = self.create_timer(0.1, self.control_loop)
        self.get_logger().info('Controlador listo, esperando trayectorias en /pose...')

    def pose_callback(self, msg):
        self.get_logger().info(f'Nueva meta recibida! X: {msg.pose.position.x}, Y: {msg.pose.position.y}')
        
        # Desempaquetar instrucciones
        angle_diff = msg.pose.orientation.z
        self.dir_giro = 1.0 if angle_diff >= 0 else -1.0
        
        # Aplicando el Kp de giro al tiempo
        self.rotate_time = (abs(angle_diff) / self.w_max) * self.kp_giro
        
        self.v_actual = msg.target_velocity
        
        # Aplicando el Kp lineal al tiempo
        self.forward_time = msg.target_time * self.kp_lineal

        # Iniciar maquina de estados
        self.state = 0
        self.state_start_time = self.get_clock().now()

    def control_loop(self):
        now = self.get_clock().now()
        elapsed_time = (now - self.state_start_time).nanoseconds * 1e-9
        cmd = Twist()

        if self.state == 0:
            # Girar
            cmd.angular.z = self.w_max * self.dir_giro
            if elapsed_time >= self.rotate_time:
                self.state = 1
                self.state_start_time = now
                self.get_logger().info('Giro terminado. Avanzando...')

        elif self.state == 1:
            # Avanzar
            cmd.linear.x = self.v_actual
            if elapsed_time >= self.forward_time:
                self.state = 2
                self.state_start_time = now

        elif self.state == 2:
            # Parada y esperar siguiente
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.get_logger().info('Meta alcanzada. Esperando siguiente instrucción...')
            self.state = 3 # Vuelve a reposo

        elif self.state == 3:
            # Reposo (no hace nada)
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0

        self.cmd_vel_pub.publish(cmd)

    def wait_for_ros_time(self):
        while rclpy.ok():
            if self.get_clock().now().nanoseconds > 0: break
            rclpy.spin_once(self, timeout_sec=0.1)

def main(args=None):
    rclpy.init(args=args)
    node = OpenLoopCtrl()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
