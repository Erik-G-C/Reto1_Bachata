import rclpy
from rclpy.node import Node
import math
import numpy as np
from geometry_msgs.msg import Pose
# Asegurate de importar tu mensaje custom correctamente
from puzzlebot_msgs.msg import CustomPose

class PathGenerator(Node):
    def __init__(self):
        super().__init__('path_generator')
        
        # Publicador al topico /pose con el mensaje CustomPose
        self.pose_pub = self.create_publisher(CustomPose, 'pose', 10)
        
        # LÍMITES DE SEGURIDAD PARA EL ROBOT
        self.v_max = 0.5   
        self.w_max = 0.5   

        self.puntos = []
        self.parametros = []
        
        self.get_logger().info('--- CONFIGURACION DE TRAYECTORIA ---')
        for i in range(4):
            x = float(input(f"Ingrese coordenada X para el Punto {i+1}: "))
            y = float(input(f"Ingrese coordenada Y para el Punto {i+1}: "))
            self.puntos.append((x, y))

        modo = input("¿Desea ingresar [v]elocidad o [t]iempo? (v/t): ").strip().lower()

        for i in range(4):
            val = float(input(f"Valor para ir al Punto {i+1}: "))
            self.parametros.append(val)

        print("\n--- REPORTE DE TRAYECTORIA ---")
        current_x = 0.0
        current_y = 0.0
        current_theta = 0.0
        
        self.mensajes_a_enviar = []

        for i in range(4):
            tx, ty = self.puntos[i]
            
            dx = tx - current_x
            dy = ty - current_y
            dist = math.sqrt(dx**2 + dy**2)
            
            target_angle = math.atan2(dy, dx)
            angle_diff = self.wrap_to_Pi(target_angle - current_theta)
            
            if modo == 'v':
                v = self.parametros[i]
                t = dist / v if v != 0 else 0
            else:
                t = self.parametros[i]
                v = dist / t if t != 0 else 0

            # =======================================================
            # OPCIÓN 1: FILTRO DE SEGURIDAD (ANTI-BROWNOUT)
            # =======================================================
            alcanzable = "Alcanzable"
            if v > self.v_max:
                alcanzable = f"No alcanzable (Excede V_max). Limitando a {self.v_max} m/s"
                v = self.v_max
                t = dist / v if v != 0 else 0 # Recalcular el tiempo
            # =======================================================

            print(f"Punto {i+1}: ({tx}, {ty})")
            print(f"Distancia: {dist:.2f} m")
            print(f"Ángulo requerido: {math.degrees(target_angle):.2f}°")
            print(alcanzable)
            print(f"Velocidad usada: {v:.2f} m/s")
            print(f"Tiempo estimado: {t:.2f} s\n")
            
            # Preparar mensaje Custom
            msg = CustomPose()
            msg.pose.position.x = tx
            msg.pose.position.y = ty
            # Mandamos el angulo de giro necesario en la orientacion Z para facilitar al controlador
            msg.pose.orientation.z = float(angle_diff) 
            msg.target_velocity = float(v)
            msg.target_time = float(t)
            self.mensajes_a_enviar.append(msg)

            current_x = tx
            current_y = ty
            current_theta = target_angle

        # Enviar el primer punto despues de 3 segundos
        self.punto_actual = 0
        self.timer = self.create_timer(3.0, self.enviar_siguiente_punto)

    def enviar_siguiente_punto(self):
        if self.punto_actual < 4:
            msg = self.mensajes_a_enviar[self.punto_actual]
            self.pose_pub.publish(msg)
            self.get_logger().info(f'Enviando meta {self.punto_actual + 1} al controlador...')
            
            # Calculamos cuanto tiempo tardara el robot en hacer este trayecto para mandar el siguiente
            tiempo_giro = abs(msg.pose.orientation.z) / self.w_max
            tiempo_total = tiempo_giro + msg.target_time + 1.0 # +1s de margen de seguridad
            
            self.punto_actual += 1
            self.timer.timer_period_ns = int(tiempo_total * 1e9) # Ajustar timer al tiempo real
        else:
            self.get_logger().info('Todos los puntos enviados. Cerrando generador.')
            self.timer.cancel()

    def wrap_to_Pi(self, theta):
        result = np.fmod((theta + np.pi), (2 * np.pi))
        if result < 0:
            result += 2 * np.pi
        return result - np.pi

def main(args=None):
    rclpy.init(args=args)
    node = PathGenerator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
