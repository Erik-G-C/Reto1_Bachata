# Imports
import rclpy
from rclpy.node import Node
import numpy as np
from geometry_msgs.msg import Twist

# Class Definition
class OpenLoopCtrl(Node):
    def __init__(self):
        super().__init__('open_loop_ctrl')

        self.wait_for_ros_time()

        # Publisher to /cmd_vel
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)

        # Maquina de estados: 0: Recto, 1: Giro, 2: Parada
        self.state = 0  
        self.state_start_time = self.get_clock().now()
        
        # Contador de lados del cuadrado
        self.side_count = 0

        # ==========================================================
        # CONFIGURACION DE ROBUSTEZ (Kps de calibracion)
        # ==========================================================
        self.kp_lineal = 0.93       # Ajuste para distancia de 2m
        self.kp_giro = 0.9375      # Ajuste para giro de 90 grados

        # Definicion de velocidades
        self.linear_speed = 0.2    # m/s
        self.angular_speed = 0.5   # rad/s

        # Definicion de tiempos calculados (Auto-tunning basado en consigna)
        self.distancia_objetivo = 2.0      # metros
        self.angulo_objetivo = np.pi / 2   # 90 grados en radianes

        self.forward_time = (self.distancia_objetivo / self.linear_speed) * self.kp_lineal
        self.rotate_time = (self.angulo_objetivo / self.angular_speed) * self.kp_giro

        # Timer para el loop de control
        self.timer_period = 0.1  # 10 Hz para mayor precision
        self.timer = self.create_timer(self.timer_period, self.control_loop)

        self.get_logger().info('Iniciando reto del cuadrado de 2m...')
        
    def control_loop(self):
        now = self.get_clock().now()
        elapsed_time = (now - self.state_start_time).nanoseconds * 1e-9

        cmd = Twist()

        # ESTADO 0: AVANZAR 2 METROS
        if self.state == 0:
            cmd.linear.x = self.linear_speed
            self.get_logger().info('Lado %d: Avanzando... %.2fs' % (self.side_count + 1, elapsed_time))
            
            if elapsed_time >= self.forward_time:
                self.state = 1  # Cambiar a Giro
                self.state_start_time = now
                self.get_logger().info('Distancia alcanzada. Iniciando giro...')

        # ESTADO 1: GIRAR 90 GRADOS
        elif self.state == 1:
            cmd.angular.z = self.angular_speed
            self.get_logger().info('Lado %d: Girando 90 grados... %.2fs' % (self.side_count + 1, elapsed_time))

            if elapsed_time >= self.rotate_time:
                self.side_count += 1
                
                # Si completamos 4 lados, nos detenemos
                if self.side_count >= 4:
                    self.state = 2
                    self.get_logger().info('Cuadrado completado con exito!')
                else:
                    self.state = 0  # Siguiente lado
                
                self.state_start_time = now
                self.get_logger().info('Giro completado. Lados listos: %d' % self.side_count)

        # ESTADO 2: PARADA FINAL
        elif self.state == 2:
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.get_logger().info('Robot en posicion final. Deteniendo nodo.')
            self.cmd_vel_pub.publish(cmd)
            self.timer.cancel()
            return

        # Publicar el comando de velocidad
        self.cmd_vel_pub.publish(cmd)

    def wait_for_ros_time(self):
        self.get_logger().info('Esperando tiempo de ROS...')
        while rclpy.ok():
            now = self.get_clock().now()
            if now.nanoseconds > 0:
                break
            rclpy.spin_once(self, timeout_sec=0.1)
        self.get_logger().info('Tiempo activo. Iniciando...')

# Main
def main(args=None):
    rclpy.init(args=args)
    node = OpenLoopCtrl()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()